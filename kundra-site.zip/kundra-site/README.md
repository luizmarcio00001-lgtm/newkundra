# Site da Kundra

Site estático responsivo em HTML, CSS e JavaScript. Não precisa instalar dependências.

## Publicação no GitHub e Vercel

1. Crie um repositório no GitHub e envie **todos** os arquivos da pasta, mantendo `assets/`.
2. Na Vercel, escolha **Add New → Project → Import Git Repository**.
3. Framework preset: **Other**. Build command: **vazio**. Output directory: **.** (raiz).
4. Clique em Deploy.

Também é possível publicar via GitHub Pages: Settings → Pages → Deploy from a branch → main / root.

## Formulário

O formulário usa `wa.me` e gera uma mensagem pré-preenchida com nome, empresa, telefone, serviço e objetivo. O cliente confirma o envio no WhatsApp. Não há banco de dados ou armazenamento de informações no site.

Para trocar o WhatsApp, altere `WHATSAPP_NUMBER` em `script.js` e o link no rodapé de `index.html`.

## Personalização

- `index.html`: textos, pacotes e preços.
- `styles.css`: cores, fontes, espaçamentos e responsividade.
- `assets/hero-montanha.png`: imagem de capa.
- `script.js`: formulário, menu mobile e botões de pacotes.

**Atenção:** Confirme os pacotes, quantidades e valores antes de publicar. Não há depoimentos ou resultados inventados no site.
